import 'package:flutter_book_non_nullsafe/base_model.dart';

FinalesModel finalesModel = FinalesModel();

class Finale {
  int id;
  String title;
  String content;
  String color;

  String toString() {
    return "{ id=$id, title=$title, content=$content, color=$color }";
  }
}

class FinalesModel extends BaseModel<Finale> {
  String color;

  void setColor(String color) {
    this.color = color;
    notifyListeners();
  }
}
